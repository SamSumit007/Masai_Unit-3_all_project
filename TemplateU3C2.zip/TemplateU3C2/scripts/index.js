// let container = document.getElementById("container");
// async function getMoviesData() {
// // try{
// let res = await fetch("https://www.themealdb.com/images/media/meals/urtpqw1487341253.jpg");

// let data = await res.json();
// console.log("data:", data);


// // showMovies(data)

// }  
// getMoviesData()


/*/

meals: Array(11)
0:
idMeal: "52807"
strMeal: "Baingan Bharta"
strMealThumb: "https://www.themealdb.com/images/media/meals/urtpqw1487341253.jpg"
/*/
let url = `https://www.themealdb.com/images/media/meals/urtpqw1487341253.jpg`;

async function getProducts() {
  try {
    let productsList = await fetchProducts(url); 
    renderProducts(productsList);
    
  } catch (error) {
    console.log(error);
  }
}
getProducts();


let cart = localStorage.getItem("cart");
if (!cart) {
 
  cart = []; 
  localStorage.setItem("cart", JSON.stringify(cart));
  refreshCartCount(cart);
} else {
  
  cart = JSON.parse(cart); 
  refreshCartCount(cart);
}

function refreshCartCount(cart) {

  let cartCount = document.getElementById("count");
  cartCount.textContent = " Cart Count : " + cart.length;
}

function fetchProducts(url) {
  return fetch(url) 
    .then(function (res) {
      return res.json(); 
    })
    .then(function (res) {
      return res; 
    })
    .catch(function (err) {
      console.log(err);
    });
}
function renderProducts(products) {
   
    let menu = document.getElementById("menu");
    menu.innerHTML = ""; 

    products.forEach(function (prod) {
     
      let prodCard = document.createElement("div");
   
      let strMealThumb = document.createElement("img");
      strMealThumb.src = prod.strMealThumb; 
      let strMeal = document.createElement("p");
      strMeal.textContent = prod.strMeal;

      let price = document.createElement("p");
       price = Math.round(Math.random()*(500 + 100));
      price.textContent = "Price : INR " + prod.price;

      
      let addToCartButton = document.createElement("button");
      addToCartButton.textContent = "Add to Cart";
      addToCartButton.onclick = function (event) {
       
        addToCart(prod);
      };

      prodCard.append(strMealThumb, strMeal, price, addToCartButton);
      menu.append(prodCard);
    });

    function addToCart(prod) {
      
      let cart = JSON.parse(localStorage.getItem("cart")); 

      cart.push(prod); 

      localStorage.setItem("cart", JSON.stringify(cart)); 
      refreshCartCount(cart); 
    }
  }