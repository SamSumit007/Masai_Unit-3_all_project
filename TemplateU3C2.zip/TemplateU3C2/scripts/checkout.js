function createOrder() {
    let Name = document.getElementById("Name").value;
    let Number = document.getElementById("num").value;
    let Address = document.getElementById("Adress").value;
    console.log(Name, Number, Address);
    if (Name && Number && Address) {
      setTimeout(function () {
        alert("order has been created successfully");
      }, 3000);
     
    }
  }